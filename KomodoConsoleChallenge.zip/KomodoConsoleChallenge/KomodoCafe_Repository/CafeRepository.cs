﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KomodoCafe_Repository
{
    public class CafeRepository
    {
        public const int _SIZE = 5;
        public string[] _MenuItems = new string[_SIZE];
    }
}
